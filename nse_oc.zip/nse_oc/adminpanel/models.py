from django.db import models

class Users(models.Model):
    name=models.CharField(max_length=100)
    email=models.EmailField(max_length=50)
    mobile=models.BigIntegerField()
    password=models.CharField(max_length=50)
    city=models.CharField(max_length=100)
    address=models.CharField(max_length=250)
    pincode=models.CharField(max_length=100)