from django.shortcuts import render,redirect
from django.contrib.auth.models import auth
from django.contrib.auth.hashers import make_password
from django.contrib.auth.base_user import BaseUserManager
from django.contrib import messages
from . models import Users

# Create your views here.


def home(request):
    return render(request,'home.html')


def signup(request):
    return render(request,'signup.html')



def register(request):
    
    if request.method == 'POST':
        name= request.POST['name']
        email = request.POST['email']
        mobile = request.POST['mobile']
        city = request.POST['city']
        address = request.POST['address']
        pincode = request.POST['pincode']

        password = BaseUserManager().make_random_password()

        if(Users.objects.filter(email = email).exists()):
            messages.info(request,'email taken')
            return redirect('/signup')
        
        elif(Users.objects.filter(mobile = mobile).exists()):
            messages.info(request,'mobile taken')
            return redirect('/signup')
        
        else:
            user=Users.objects.create(name=name, email=email, mobile=mobile, city=city, address=address, pincode=pincode,password=password)
            user.save()
            return redirect('login')
        return redirect('/')
    else:
        return render(request,'signup.html')
       



def checkLogin(request):
    if request.method == 'POST':
        mobile = request.POST['mobile']
        password = request.POST['pass']
        user = Users.objects.get(mobile=mobile)
        if Users.objects.filter(mobile = mobile).exists():           
            if Users.objects.filter(password = password).exists():    
                try:
                    request.session['uid']=user.id
                except Users.DoesNotExist:
                    return render('login')

                return render(request, 'home.html')
        else:
            messages.info(request, 'invalid credentials')
            #print("hiiiiii")
            return redirect('login')

    else:    
        return render(request,'login.html')

def profile(request):
    print(request.session.id)
    user = Users.objects.get(id=request.session.uid)
    
    return render(request, 'profile.html',{'data':user})  

def oclist(request):
    return render(request,'optionchangelist.html')
